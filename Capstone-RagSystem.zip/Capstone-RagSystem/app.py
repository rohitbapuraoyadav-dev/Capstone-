import os
import streamlit as st
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_community.retrievers import BM25Retriever
from langchain_ollama import ChatOllama
import time

# =====================================================
# PAGE CONFIG
# =====================================================

st.set_page_config(
    page_title="Care Management Assistant",
    page_icon="🏥",
    layout="wide"
)




# =====================================================
# SESSION STATE
# =====================================================

if "messages" not in st.session_state:
    st.session_state.messages = []

# =====================================================
# LOAD EMBEDDINGS
# =====================================================

@st.cache_resource
def load_embeddings():

    return HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )

# =====================================================
# LOAD VECTOR DB
# =====================================================

@st.cache_resource
def load_vector_db():

    embeddings = load_embeddings()

    return FAISS.load_local(
        "vector_db",
        embeddings,
        allow_dangerous_deserialization=True
    )

# =====================================================
# LOAD LLM
# =====================================================
@st.cache_resource
def load_llm():

    return ChatOllama(
        model="llama3.2",
        temperature=0
    )

# =====================================================
# LOAD COMPONENTS
# =====================================================

vectorstore = load_vector_db()

llm = load_llm()

# =====================================================
# CREATE RETRIEVERS
# =====================================================

all_docs = vectorstore.similarity_search(
    "patient",
    k=1000
)

bm25_retriever = BM25Retriever.from_documents(
    all_docs
)

bm25_retriever.k = 3

faiss_retriever = vectorstore.as_retriever(
    search_kwargs={"k": 3}
)
# =====================================================
# HYBRID RETRIEVAL
# =====================================================
def hybrid_retrieve(query):

    bm25_docs = bm25_retriever.invoke(query)

    faiss_docs = faiss_retriever.invoke(query)

    all_results = bm25_docs + faiss_docs

    unique_docs = []

    seen = set()

    for doc in all_results:

        if doc.page_content not in seen:

            seen.add(doc.page_content)

            unique_docs.append(doc)

    return unique_docs

# =====================================================
# RAG FUNCTION
# =====================================================
def ask_rag(question):

    docs = hybrid_retrieve(question)

    context = "\n\n".join(
        doc.page_content
        for doc in docs
    )

    prompt = f"""
You are an Expert Healthcare Care Management Assistant.

Instructions:

1. Use ONLY the retrieved context.
2. Combine information from multiple retrieved documents when relevant.
3. Provide professional healthcare recommendations.
4. Use bullet points where appropriate.
5. Do not invent facts.
6. If information is not available in the context, clearly state that it was not found in the provided documents.

Retrieved Context:

{context}

Question:
{question}

Answer:
"""

    response = llm.invoke(prompt)

    return response.content, docs

# =====================================================
# SIDEBAR
# =====================================================
with st.sidebar:

    st.image(
    "https://img.icons8.com/color/96/hospital.png",
    width=80
    )

    st.title("Healthcare RAG")

    st.success("System Online")

    st.divider()

    st.subheader("Technology Stack")

    st.write("🔹 BM25 Retrieval")
    st.write("🔹 FAISS Vector Search")
    st.write("🔹 CrossEncoder Re-ranking")
    st.write("🔹 Llama 3.2")
    st.write("🔹 Streamlit")

    st.divider()

    st.subheader("Sample Questions")

    st.caption(
        "• What are characteristics of high-risk patients?"
    )

    st.caption(
        "• What interventions reduce readmissions?"
    )

    st.caption(
        "• What follow-up is required after discharge?"
    )

    st.divider()

    if st.button("🗑 Clear Chat"):
        st.session_state.messages = []
        st.rerun()

# =====================================================
# MAIN HEADER
# =====================================================

st.title("🏥 Care Management Assistant")

st.caption(
    "AI-powered Healthcare Readmission Prevention System"
)

# =====================================================
# METRICS
# =====================================================
m1, m2, m3, m4 = st.columns(4)

with m1:
    st.metric(
        "📄 Documents",
        len(all_docs)
    )

with m2:
    st.metric(
        "🔍 Retriever",
        "Hybrid"
    )

with m3:
    st.metric(
        "🧠 Model",
        "Llama 3.2"
    )

with m4:
    st.metric(
        "🎯 Re-ranking",
        "Enabled"
    )

st.divider()

# =====================================================
# DISPLAY CHAT HISTORY
# =====================================================

for msg in st.session_state.messages:

    with st.chat_message(msg["role"]):

        st.markdown(msg["content"])

# =====================================================
# USER INPUT
# =====================================================

question = st.chat_input(
    "Ask a healthcare question..."
)

# =====================================================
# PROCESS QUESTION
# =====================================================

if question:

    st.session_state.messages.append(
        {
            "role": "user",
            "content": question
        }
    )

    with st.chat_message("user"):
        st.markdown(question)

    with st.spinner(
        "Searching healthcare policies..."
    ):
        
        start_time = time.time()
        answer, docs = ask_rag(question)
        response_time = round(
            time.time() - start_time,2
        )

    with st.chat_message("assistant"):

        st.markdown(answer)
        st.caption(
            f"⚡ Response Time: {response_time}s")

        st.divider()

        st.markdown("### 📄 Sources")

        displayed = set()

        for doc in docs:

            source = doc.metadata.get(
                "source",
                "Unknown Source"
            )

            source_name = os.path.basename(
                source
            )

            if source_name not in displayed:

                displayed.add(source_name)

                st.write(
                    f"📄 {source_name}"
                )

    st.session_state.messages.append(
        {
            "role": "assistant",
            "content": answer
        }
    )