from langchain_community.document_loaders import (
    TextLoader,
    PyMuPDFLoader
)

from langchain_core.documents import Document
from docx import Document as DocxDocument
import os

all_documents = []

print("Current Working Directory:")
print(os.getcwd())

# ==================================
# PDF Loader
# ==================================

pdf_folder = "data/pdfs"

print("\nChecking PDF Folder:")
print(pdf_folder)

if os.path.exists(pdf_folder):

    files = os.listdir(pdf_folder)

    print("PDF Files Found:")
    print(files)

    for file in files:

        if file.lower().endswith(".pdf"):

            path = os.path.join(pdf_folder, file)

            try:

                loader = PyMuPDFLoader(path)

                docs = loader.load()

                all_documents.extend(docs)

                print(f"[PDF] Loaded: {file}")

            except Exception as e:

                print(f"[PDF] Failed: {file}")

                print(e)

else:

    print("PDF Folder Not Found!")


# ==================================
# DOCX Loader
# ==================================

docx_folder = "data/docs"

print("\nChecking DOCX Folder:")
print(docx_folder)

if os.path.exists(docx_folder):

    print("DOCX Files:", os.listdir(docx_folder))

    for file in os.listdir(docx_folder):

        if file.lower().endswith(".docx"):

            path = os.path.join(docx_folder, file)

            try:

                doc = DocxDocument(path)

                text = "\n".join(
                    para.text
                    for para in doc.paragraphs
                )

                all_documents.append(
                    Document(
                        page_content=text,
                        metadata={
                            "source": file,
                            "type": "docx"
                        }
                    )
                )

                print(f"[DOCX] Loaded: {file}")

            except Exception as e:

                print(f"[DOCX] Failed: {file}")
                print(e)

else:

    print("DOCX Folder Not Found!")

# ==================================
# TXT Loader
# ==================================

txt_folder = "data/txt"

print("\nChecking TXT Folder:")
print(txt_folder)

if os.path.exists(txt_folder):

    files = os.listdir(txt_folder)

    print("TXT Files Found:")
    print(files)

    for file in files:

        if file.lower().endswith(".txt"):

            path = os.path.join(txt_folder, file)

            try:

                loader = TextLoader(
                    path,
                    encoding="utf-8"
                )

                docs = loader.load()

                all_documents.extend(docs)

                print(f"[TXT] Loaded: {file}")

            except Exception as e:

                print(f"[TXT] Failed: {file}")
                print(e)

else:

    print("TXT Folder Not Found!")

# ==================================
# SUMMARY
# ==================================

print("\n" + "=" * 60)
print("TOTAL DOCUMENTS:", len(all_documents))
print("=" * 60)

for i, doc in enumerate(all_documents):

    print(f"\nDocument {i+1}")

    print("Metadata:")
    print(doc.metadata)

    print("\nPreview:")
    print(doc.page_content[:300])

    print("-" * 60)


# STEP 2 : Chunking the documents into smaller chunks 

from langchain_text_splitters import (
    RecursiveCharacterTextSplitter
)

text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200,
    length_function=len
)

chunks = text_splitter.split_documents(
    all_documents
)

print("Total Chunks:", len(chunks))

# print 5 chunks 
for i, chunk in enumerate(chunks[:5]):

    print("="*50)

    print(f"Chunk {i+1}")

    print(chunk.page_content[:500])

# ==================================
# EMBEDDING MODEL
# ==================================

from langchain_huggingface import HuggingFaceEmbeddings

embedding_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

print("Embedding Model Loaded Successfully")


# ==================================
# FAISS VECTOR DATABASE
# ==================================

from langchain_community.vectorstores import FAISS

vectorstore = FAISS.from_documents(
    chunks,
    embedding_model
)

print("FAISS Vector Store Created")

vectorstore.save_local("vector_db")

print("Vector Store Saved")

# ==================================
# FAISS RETRIEVER
# ==================================

faiss_retriever = vectorstore.as_retriever(
    search_kwargs={"k": 5}
)

# ==================================
# BM25 RETRIEVER
# ==================================

from langchain_community.retrievers import BM25Retriever

bm25_retriever = BM25Retriever.from_documents(
    chunks
)

bm25_retriever.k = 5

print("BM25 Retriever Created")


from sentence_transformers import CrossEncoder

def load_reranker():

    return CrossEncoder(
        "cross-encoder/ms-marco-MiniLM-L-6-v2"
    )

reranker = load_reranker()

def rerank_documents(
    query,
    docs,
    top_k=3
):

    pairs = [
        (query, doc.page_content)
        for doc in docs
    ]

    scores = reranker.predict(
        pairs
    )

    scored_docs = list(
        zip(docs, scores)
    )

    scored_docs.sort(
        key=lambda x: x[1],
        reverse=True
    )

    reranked_docs = [
        doc
        for doc, score
        in scored_docs[:top_k]
    ]

    return reranked_docs

# ==================================
# HYBRID RETRIEVER
# ==================================

def hybrid_retrieve(query):

    bm25_docs = bm25_retriever.invoke(query)

    faiss_docs = faiss_retriever.invoke(query)

    all_results = bm25_docs + faiss_docs

    unique_docs = []

    seen = set()

    for doc in all_results:

        if doc.page_content not in seen:

            seen.add(doc.page_content)

            unique_docs.append(doc)

    reranked_docs = rerank_documents(
        query,
        unique_docs,
        top_k=3
    )

    return reranked_docs

# ==================================
# LLM
# ==================================

from langchain_ollama import ChatOllama

llm = ChatOllama(
    model="llama3.2",
    temperature=0
)

print("Llama 3.2 Loaded")

# ==================================
# HYBRID RAG FUNCTION
# ==================================

def ask_rag(question):

    # Retrieve documents using Hybrid Search
    docs = hybrid_retrieve(question)

    # Create context
    context = "\n\n".join(
        doc.page_content
        for doc in docs
    )

    # Prompt
    prompt = f"""
You are a Care Management AI Assistant supporting nurses, care managers, discharge teams, hospital coordinators, and case managers.

Your responsibility is to answer questions using ONLY the information provided in the retrieved context.

Instructions:

1. Carefully review all retrieved context before answering.
2. Combine information from multiple retrieved documents when relevant.
3. Provide a clear, professional, and well-structured response.
4. If the context contains partial information, provide the available information and explain any limitations.
5. Do NOT make up facts or use outside medical knowledge.
6. Do NOT mention chunk numbers, similarity scores, embeddings, BM25, FAISS, or retrieval details.
7. When applicable, summarize recommendations using bullet points.
8. If no direct answer exists, provide the closest relevant information available from the context.
9. Only state that information is unavailable when the retrieved context contains no relevant information at all.
10. Focus on practical care-management recommendations that help reduce patient readmissions.


Retrieved Context:

{context}

Question:
{question}

Professional Response:
"""

    # Generate Answer
    response = llm.invoke(prompt)

    return response.content, docs


# ==================================
# TEST QUERY
# ==================================

question = "What should be included in a patient file?"

answer, docs = ask_rag(question)

print("\n" + "=" * 80)
print("QUESTION")
print("=" * 80)
print(question)

print("\n" + "=" * 80)
print("ANSWER")
print("=" * 80)
print(answer)

print("\n" + "=" * 80)
print("SOURCES")
print("=" * 80)

for doc in docs:
    print(doc.metadata)


# ==================================
# CHAT LOOP
# ==================================

while True:

    question = input("\nAsk Question (type exit to quit): ")

    if question.lower() == "exit":
        print("Exiting Care Management Assistant...")
        break

    answer, docs = ask_rag(question)

    print("\n" + "=" * 80)
    print("ANSWER")
    print("=" * 80)
    print(answer)

    print("\n" + "=" * 80)
    print("SOURCES")
    print("=" * 80)

    displayed_sources = set()

    for doc in docs:

        source_name = doc.metadata.get(
            "source",
            "Unknown Source"
        )

        if source_name not in displayed_sources:

            displayed_sources.add(source_name)

            print(source_name)